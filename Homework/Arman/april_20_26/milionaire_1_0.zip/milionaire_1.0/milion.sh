#!/bin/bash
# Who wants to be a Millionaire?
# create Arman Kostandyan

#
# array for answers
#**********
arr[1]="A"
arr[2]="C"
arr[3]="B"
arr[4]="C"
arr[5]="A"
arr[6]="B"
arr[7]="B"
arr[8]="D"
arr[9]="B"
arr[10]="C"
#**********

QUESTION_NUMBER=0
SCORE=0
#
#   function for record list
record () {    
clear
echo     
echo "coming soon"
sleep 3
menu_func
}

#   function for exit mode
exit_func () {
clear
echo "EXIT? [Y/N]"
read yes_no
case "$yes_no" in
    "Y" | "y" | "yes" | "Yes" )
    clear
    exit
    ;;
    "N" | "n" | "No" | "no" )
    menu_func
    ;;
    * )
    echo "not found!"
    exit_func
    ;;
esac
}

#   function for choose name.
nickname () { 
clear
echo
echo -n "Enter your nickname and press [ENTER] :  "
read nickname
}

#   function for menu
menu_func () {
clear
echo
echo "************ MENU *************"
echo "Hi $nickname, choose... "
echo "1. Play! "
echo "2. Record (soon)"
echo "3. Help (soon)"
echo "4. Exit "
echo "******************************* "
echo
echo -n "choose: "
read menu

case "$menu" in
    "1") 
    play
    ;;
    "2")
    record
    ;;
    "3")
    help_func
    ;;
    "4")
    exit_func
    ;;
    * )
    clear
    echo "Error! Try again."
    menu_func
    ;;
esac
}

help_func () {
clear
echo
echo "Soon!"
sleep 3
menu_func
}

#   function for play mode
play () {
    clear
    for (( i=1; i<=10; i++ )) 
    do
        step
    done
}

step () {
while true
do
    FILE_NAME=$RANDOM
    FILE_PATH="question/$FILE_NAME"
    if [ -f $FILE_PATH ]
    then
        print_question
        check_answer
    fi
    clear
done
}

#   function print of question
print_question () {
let "QUESTION_NUMBER += 1"
echo "50/50 [F]    google [G]     +10 time [T]  (soon)"
echo
echo -n "$QUESTION_NUMBER) "    
while read line
do
    echo -e "$line"
done<$FILE_PATH
}

#   function for check of answer
check_answer () {
echo -n "your answer: "
read answ
if [[ "$answ" == "${arr[$FILE_NAME]}"  ]]; then
    let "SCORE += 100"
    clear
    echo "Right!"
    echo "your score $nickname: $SCORE"
if [ "$SCORE" -eq "1000" ]; then
    clear
    echo "YOU WIN!!"
    sleep 5
    menu_func
fi

    echo -n "Contiune? [Y/N]"
    read yes_no_1
        case "$yes_no_1" in
            "Y" | "y" | "yes" | "Yes" )
                continue
                ;;
            "N" | "n" | "No" | "no" )
                menu_func
                ;;
            * )
                echo "not found!"
                ;;
        esac
else
   case "$answ" in
   "G" | "g" )
      google_func
      ;;
   "F" | "f" )
      fifty_func
      ;;
   "T" | "t" )
      time_func
      ;;
   * )
      echo
      echo "right answer: ${arr[$FILE_NAME]}"
      echo
      echo "***GAME OVER!***"
      echo "Your score $nickname: $SCORE "
      sleep 5
      clear
      menu_func
      ;;
esac
fi
    }

nickname
menu_func
